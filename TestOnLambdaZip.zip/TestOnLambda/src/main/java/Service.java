import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

public class Service {

    public Response getResponse(Request input){

        Response response = new Response();
        ObjectMapper mapper = new ObjectMapper();
        try {
            BodyData data = mapper.readValue(input.getBody() , BodyData.class);
            response.setBody(data.toString());
            response.setStatusCode(200);

        } catch (IOException e) {
            response.setBody(e.getMessage());
            response.setStatusCode(500);
        }
        return response;
    }
}

public class BodyData {

    private String name;
    private Integer marks;
    private String address;

    public BodyData(String name, Integer marks, String address) {
        this.name = name;
        this.marks = marks;
        this.address = address;
    }

    @Override
    public String toString() {
        return "BodyData{" +
                "name='" + name + '\'' +
                ", marks=" + marks +
                ", address='" + address + '\'' +
                '}';
    }

    public BodyData() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getMarks() {
        return marks;
    }

    public void setMarks(Integer marks) {
        this.marks = marks;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}

package AnotherPackage;

import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.InstanceNotFoundException;
import com.amazonaws.services.ec2.model.InstanceStateName;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Base64;

public class ReadWildFlyLogs implements RequestHandler<Object, Object> {

    private static final String INSTANCE_ID = "YOUR_INSTANCE_ID_HERE";
    private static final String LOG_FILE_PATH = "/opt/wildfly/standalone/log/server.log";

    @Override
    public Object handleRequest(Object input, Context context) {
        AmazonEC2 ec2 = AmazonEC2ClientBuilder.defaultClient();
        Instance instance = getRunningInstance(ec2, INSTANCE_ID);

        if (instance == null) {
            context.getLogger().log(String.format("EC2 instance %s is not running.", INSTANCE_ID));
            return null;
        }

        String logFileContents = retrieveLogFileContents(instance, LOG_FILE_PATH);
        context.getLogger().log(logFileContents);

        return null;
    }

    private Instance getRunningInstance(AmazonEC2 ec2, String instanceId) {
        try {
            Instance instance = ec2.describeInstances().getReservations().stream()
                    .flatMap(reservation -> reservation.getInstances().stream())
                    .filter(i -> i.getInstanceId().equals(instanceId) && i.getState().getName().equals(InstanceStateName.Running.toString()))
                    .findFirst()
                    .orElse(null);

            return instance;
        } catch (Exception e) {
            return null;
        }
    }

    private String retrieveLogFileContents(Instance instance, String logFilePath) {
        try {
            String command = String.format("sudo cat %s", logFilePath);
            InputStream inputStream = instance.getConnection().getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            instance.getConnection().sendString(command + "\n");
            String output = "";
            String line = reader.readLine();
            while (line != null) {
                output += line + "\n";
                line = reader.readLine();
            }
            return new String(Base64.getDecoder().decode(output));
        } catch (IOException e) {
            return "";
        }
    }
}

